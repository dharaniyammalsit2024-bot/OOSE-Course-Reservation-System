import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Online Course Reservation System - Desktop Application (OOSE Mini Project)
 *
 * Main actors: Student, Admin
 * Use cases: Register, Login, View Courses, Search Courses, Reserve Course (Pay Fee),
 *            View Reservations, Cancel Reservation, Add Course (Admin), Logout
 *
 * Data is persisted to local text files so records survive restarts.
 */
public class CourseReservationApp extends JFrame {

    // ---------------- Models ----------------
    static class Course implements Serializable {
        String code, title, instructor, schedule;
        int seats;
        double fee;
        Course(String code, String title, String instructor, String schedule, int seats, double fee) {
            this.code = code; this.title = title; this.instructor = instructor;
            this.schedule = schedule; this.seats = seats; this.fee = fee;
        }
        String toLine() { return code + "|" + title + "|" + instructor + "|" + schedule + "|" + seats + "|" + fee; }
        static Course fromLine(String l) {
            String[] p = l.split("\\|");
            return new Course(p[0], p[1], p[2], p[3], Integer.parseInt(p[4]), Double.parseDouble(p[5]));
        }
    }

    static class Reservation implements Serializable {
        String studentEmail, studentName, courseCode, courseTitle, paymentMode;
        double feePaid;
        Reservation(String studentEmail, String studentName, String courseCode, String courseTitle, double feePaid, String paymentMode) {
            this.studentEmail = studentEmail; this.studentName = studentName;
            this.courseCode = courseCode; this.courseTitle = courseTitle;
            this.feePaid = feePaid; this.paymentMode = paymentMode;
        }
        String toLine() { return studentEmail + "|" + studentName + "|" + courseCode + "|" + courseTitle + "|" + feePaid + "|" + paymentMode; }
        static Reservation fromLine(String l) {
            String[] p = l.split("\\|");
            return new Reservation(p[0], p[1], p[2], p[3], Double.parseDouble(p[4]), p[5]);
        }
    }

    static class User implements Serializable {
        String name, email, password, role; // role: STUDENT / ADMIN
        User(String name, String email, String password, String role) {
            this.name = name; this.email = email; this.password = password; this.role = role;
        }
        String toLine() { return name + "|" + email + "|" + password + "|" + role; }
        static User fromLine(String l) {
            String[] p = l.split("\\|");
            return new User(p[0], p[1], p[2], p[3]);
        }
    }

    // ---------------- Data ----------------
    List<Course> courses = new ArrayList<>();
    List<Reservation> reservations = new ArrayList<>();
    Map<String, User> users = new HashMap<>();  // email -> User
    User currentUser = null;

    DefaultTableModel courseModel, reservationModel;
    CardLayout cards = new CardLayout();
    JPanel mainPanel = new JPanel(cards);

    public CourseReservationApp() {
        setTitle("Online Course Reservation System");
        setSize(900, 620);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        loadData();
        if (courses.isEmpty()) {
            courses.add(new Course("CS101", "Introduction to Programming", "Dr. Smith", "Mon/Wed 10:00", 30, 1500));
            courses.add(new Course("CS201", "Data Structures", "Prof. Johnson", "Tue/Thu 11:00", 25, 2000));
            courses.add(new Course("CS301", "Database Systems", "Dr. Kumar", "Mon/Fri 14:00", 20, 2500));
            courses.add(new Course("CS401", "Machine Learning", "Prof. Alan", "Wed 09:00", 15, 3500));
            courses.add(new Course("CS402", "Web Development", "Ms. Priya", "Fri 10:00", 40, 1800));
        }
        if (users.isEmpty()) {
            users.put("student@mail.com", new User("Demo Student", "student@mail.com", "1234", "STUDENT"));
            users.put("admin@mail.com", new User("Admin", "admin@mail.com", "admin", "ADMIN"));
        }

        mainPanel.add(buildLoginPanel(), "LOGIN");
        mainPanel.add(buildRegisterPanel(), "REGISTER");
        add(mainPanel);
        cards.show(mainPanel, "LOGIN");
    }

    // ---------------- Persistence ----------------
    void saveData() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("courses.txt"))) {
            for (Course c : courses) pw.println(c.toLine());
        } catch (IOException e) { JOptionPane.showMessageDialog(this, "Error saving courses."); }
        try (PrintWriter pw = new PrintWriter(new FileWriter("reservations.txt"))) {
            for (Reservation r : reservations) pw.println(r.toLine());
        } catch (IOException e) { JOptionPane.showMessageDialog(this, "Error saving reservations."); }
        try (PrintWriter pw = new PrintWriter(new FileWriter("users.txt"))) {
            for (User u : users.values()) pw.println(u.toLine());
        } catch (IOException e) { JOptionPane.showMessageDialog(this, "Error saving users."); }
    }

    void loadData() {
        File fc = new File("courses.txt"), fr = new File("reservations.txt"), fu = new File("users.txt");
        try {
            if (fc.exists()) { BufferedReader br = new BufferedReader(new FileReader(fc)); String l;
                while ((l = br.readLine()) != null) if (!l.isBlank()) courses.add(Course.fromLine(l)); br.close(); }
            if (fr.exists()) { BufferedReader br = new BufferedReader(new FileReader(fr)); String l;
                while ((l = br.readLine()) != null) if (!l.isBlank()) reservations.add(Reservation.fromLine(l)); br.close(); }
            if (fu.exists()) { BufferedReader br = new BufferedReader(new FileReader(fu)); String l;
                while ((l = br.readLine()) != null) if (!l.isBlank()) { User u = User.fromLine(l); users.put(u.email, u); } br.close(); }
        } catch (Exception e) { System.out.println("Could not load saved data: " + e.getMessage()); }
    }

    // ---------------- LOGIN ----------------
    JPanel buildLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 8, 8, 8);

        JLabel title = new JLabel("Online Course Reservation System");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(new Color(25, 55, 109));
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2; panel.add(title, g);

        g.gridwidth = 1; g.gridy++;
        panel.add(new JLabel("Email:"), g);
        JTextField email = new JTextField(18);
        g.gridx = 1; panel.add(email, g);

        g.gridx = 0; g.gridy++;
        panel.add(new JLabel("Password:"), g);
        JPasswordField pass = new JPasswordField(18);
        g.gridx = 1; panel.add(pass, g);

        JButton loginBtn = new JButton("Login");
        JButton regBtn = new JButton("New User? Register");
        g.gridx = 0; g.gridy++; panel.add(loginBtn, g);
        g.gridx = 1; panel.add(regBtn, g);

        JLabel hint = new JLabel("Demo: student@mail.com / 1234  |  Admin: admin@mail.com / admin");
        hint.setFont(new Font("Arial", Font.ITALIC, 11));
        hint.setForeground(Color.GRAY);
        g.gridx = 0; g.gridy++; g.gridwidth = 2; panel.add(hint, g);

        loginBtn.addActionListener(e -> {
            User u = users.get(email.getText().trim());
            if (u != null && u.password.equals(new String(pass.getPassword()))) {
                currentUser = u;
                mainPanel.add(buildDashboard(), "DASH");
                cards.show(mainPanel, "DASH");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password.");
            }
        });
        regBtn.addActionListener(e -> cards.show(mainPanel, "REGISTER"));
        return panel;
    }

    // ---------------- REGISTER ----------------
    JPanel buildRegisterPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 8, 8, 8);

        JLabel title = new JLabel("Create New Account");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2; panel.add(title, g);

        g.gridwidth = 1; g.gridy++;
        panel.add(new JLabel("Full Name:"), g);
        JTextField name = new JTextField(18); g.gridx = 1; panel.add(name, g);

        g.gridx = 0; g.gridy++;
        panel.add(new JLabel("Email:"), g);
        JTextField email = new JTextField(18); g.gridx = 1; panel.add(email, g);

        g.gridx = 0; g.gridy++;
        panel.add(new JLabel("Password:"), g);
        JPasswordField pass = new JPasswordField(18); g.gridx = 1; panel.add(pass, g);

        JButton regBtn = new JButton("Register");
        JButton backBtn = new JButton("Back to Login");
        g.gridx = 0; g.gridy++; panel.add(regBtn, g);
        g.gridx = 1; panel.add(backBtn, g);

        regBtn.addActionListener(e -> {
            if (name.getText().trim().isEmpty() || email.getText().trim().isEmpty()
                    || new String(pass.getPassword()).isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields."); return;
            }
            if (users.containsKey(email.getText().trim())) {
                JOptionPane.showMessageDialog(this, "Email already registered."); return;
            }
            users.put(email.getText().trim(),
                    new User(name.getText().trim(), email.getText().trim(), new String(pass.getPassword()), "STUDENT"));
            saveData();
            JOptionPane.showMessageDialog(this, "Registration successful! Please login.");
            cards.show(mainPanel, "LOGIN");
        });
        backBtn.addActionListener(e -> cards.show(mainPanel, "LOGIN"));
        return panel;
    }

    // ---------------- DASHBOARD ----------------
    JPanel buildDashboard() {
        JPanel panel = new JPanel(new BorderLayout());
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Available Courses", buildCoursesPanel());
        tabs.addTab("My Reservations", buildReservationsPanel());
        if (currentUser.role.equals("ADMIN"))
            tabs.addTab("Admin: Manage Courses", buildAdminPanel());
        panel.add(tabs, BorderLayout.CENTER);

        JPanel top = new JPanel(new BorderLayout());
        top.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        top.add(new JLabel("  Welcome, " + currentUser.name + "  (" + currentUser.role + ")"), BorderLayout.WEST);
        JButton logout = new JButton("Logout");
        logout.addActionListener(e -> {
            saveData();
            currentUser = null;
            cards.show(mainPanel, "LOGIN");
        });
        top.add(logout, BorderLayout.EAST);
        panel.add(top, BorderLayout.NORTH);
        return panel;
    }

    JPanel buildCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        courseModel = new DefaultTableModel(new Object[]{"Code", "Title", "Instructor", "Schedule", "Seats", "Fee"}, 0);
        refreshCourses();
        JTable table = new JTable(courseModel);
        table.setRowHeight(22);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField search = new JTextField(20);
        JButton searchBtn = new JButton("Search");
        JButton clearBtn = new JButton("Clear");
        searchRow.add(new JLabel("Search (code/title/instructor): "));
        searchRow.add(search); searchRow.add(searchBtn); searchRow.add(clearBtn);
        panel.add(searchRow, BorderLayout.NORTH);

        searchBtn.addActionListener(e -> {
            String q = search.getText().trim().toLowerCase();
            courseModel.setRowCount(0);
            for (Course c : courses)
                if (c.code.toLowerCase().contains(q) || c.title.toLowerCase().contains(q) || c.instructor.toLowerCase().contains(q))
                    courseModel.addRow(new Object[]{c.code, c.title, c.instructor, c.schedule, c.seats, "Rs. " + c.fee});
        });
        clearBtn.addActionListener(e -> { search.setText(""); refreshCourses(); });

        JButton reserveBtn = new JButton("Reserve & Pay for Selected Course");
        JPanel bottom = new JPanel(); bottom.add(reserveBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        reserveBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Please select a course."); return; }
            String code = (String) courseModel.getValueAt(row, 0);
            Course c = findCourse(code);
            if (c == null) return;
            if (c.seats <= 0) { JOptionPane.showMessageDialog(this, "Sorry, no seats available."); return; }
            showPaymentDialog(c);
        });
        return panel;
    }

    Course findCourse(String code) {
        for (Course c : courses) if (c.code.equals(code)) return c;
        return null;
    }

    // ---------------- PAYMENT ----------------
    void showPaymentDialog(Course c) {
        JDialog dialog = new JDialog(this, "Fee Payment", true);
        dialog.setSize(400, 380);
        dialog.setLocationRelativeTo(this);
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);

        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        JLabel header = new JLabel("Pay for: " + c.title + " (Rs. " + c.fee + ")");
        header.setFont(new Font("Arial", Font.BOLD, 14));
        p.add(header, g);

        g.gridwidth = 1; g.gridy++;
        p.add(new JLabel("Card Number:"), g);
        JTextField card = new JTextField(16); g.gridx = 1; p.add(card, g);

        g.gridx = 0; g.gridy++;
        p.add(new JLabel("Expiry (MM/YY):"), g);
        JTextField expiry = new JTextField(16); g.gridx = 1; p.add(expiry, g);

        g.gridx = 0; g.gridy++;
        p.add(new JLabel("CVV:"), g);
        JTextField cvv = new JTextField(16); g.gridx = 1; p.add(cvv, g);

        g.gridx = 0; g.gridy++;
        p.add(new JLabel("Payment Mode:"), g);
        JComboBox<String> mode = new JComboBox<>(new String[]{"Credit Card", "Debit Card", "UPI", "Net Banking"});
        g.gridx = 1; p.add(mode, g);

        JButton payBtn = new JButton("Pay Rs. " + c.fee);
        g.gridx = 0; g.gridy++; g.gridwidth = 2; p.add(payBtn, g);

        payBtn.addActionListener(ev -> {
            if (card.getText().trim().length() < 12 || expiry.getText().trim().isEmpty() || cvv.getText().trim().length() < 3) {
                JOptionPane.showMessageDialog(dialog, "Enter valid payment details."); return;
            }
            c.seats--;
            reservations.add(new Reservation(currentUser.email, currentUser.name, c.code, c.title, c.fee, (String) mode.getSelectedItem()));
            saveData();
            refreshCourses(); refreshReservations();
            dialog.dispose();
            JOptionPane.showMessageDialog(this,
                "Payment Successful!\nAmount Paid: Rs. " + c.fee + " via " + mode.getSelectedItem() +
                "\nReservation confirmed for " + c.title);
        });
        dialog.add(p);
        dialog.setVisible(true);
    }

    JPanel buildReservationsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        reservationModel = new DefaultTableModel(new Object[]{"Student", "Course Code", "Course Title", "Fee Paid", "Mode"}, 0);
        refreshReservations();
        JTable table = new JTable(reservationModel);
        table.setRowHeight(22);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JButton cancelBtn = new JButton("Cancel Selected Reservation");
        JPanel bottom = new JPanel(); bottom.add(cancelBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        cancelBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Please select a reservation."); return; }
            // find reservation by course code + title from the selected row
            String code = (String) reservationModel.getValueAt(row, 1);
            String title = (String) reservationModel.getValueAt(row, 2);
            Reservation target = null;
            for (Reservation r : reservations)
                if (r.courseCode.equals(code) && r.courseTitle.equals(title)
                        && (currentUser.role.equals("ADMIN") || r.studentEmail.equals(currentUser.email))) { target = r; break; }
            if (target == null) { JOptionPane.showMessageDialog(this, "Reservation not found."); return; }
            Course c = findCourse(target.courseCode);
            if (c != null) c.seats++;
            reservations.remove(target);
            saveData();
            refreshCourses(); refreshReservations();
            JOptionPane.showMessageDialog(this, "Reservation cancelled. Refund of Rs. " + target.feePaid + " initiated.");
        });
        return panel;
    }

    // ---------------- ADMIN ----------------
    JPanel buildAdminPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridLayout(6, 2, 5, 5));
        JTextField code = new JTextField(), title = new JTextField(), instructor = new JTextField(),
                   schedule = new JTextField(), seats = new JTextField(), fee = new JTextField();
        form.add(new JLabel("Course Code:")); form.add(code);
        form.add(new JLabel("Title:")); form.add(title);
        form.add(new JLabel("Instructor:")); form.add(instructor);
        form.add(new JLabel("Schedule:")); form.add(schedule);
        form.add(new JLabel("Seats:")); form.add(seats);
        form.add(new JLabel("Fee (Rs.):")); form.add(fee);
        panel.add(form, BorderLayout.CENTER);

        JButton addBtn = new JButton("Add Course");
        JPanel bottom = new JPanel(); bottom.add(addBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            try {
                if (code.getText().trim().isEmpty() || title.getText().trim().isEmpty())
                    { JOptionPane.showMessageDialog(this, "Code and title required."); return; }
                if (findCourse(code.getText().trim()) != null)
                    { JOptionPane.showMessageDialog(this, "Course code already exists."); return; }
                courses.add(new Course(code.getText().trim(), title.getText().trim(), instructor.getText().trim(),
                        schedule.getText().trim(), Integer.parseInt(seats.getText().trim()), Double.parseDouble(fee.getText().trim())));
                saveData(); refreshCourses();
                JOptionPane.showMessageDialog(this, "Course added.");
                code.setText(""); title.setText(""); instructor.setText("");
                schedule.setText(""); seats.setText(""); fee.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Seats and fee must be numbers.");
            }
        });
        return panel;
    }

    void refreshCourses() {
        if (courseModel == null) return;
        courseModel.setRowCount(0);
        for (Course c : courses)
            courseModel.addRow(new Object[]{c.code, c.title, c.instructor, c.schedule, c.seats, "Rs. " + c.fee});
    }

    void refreshReservations() {
        if (reservationModel == null) return;
        reservationModel.setRowCount(0);
        for (Reservation r : reservations)
            if (currentUser.role.equals("ADMIN") || r.studentEmail.equals(currentUser.email))
                reservationModel.addRow(new Object[]{r.studentName, r.courseCode, r.courseTitle, "Rs. " + r.feePaid, r.paymentMode});
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CourseReservationApp().setVisible(true));
    }
}
